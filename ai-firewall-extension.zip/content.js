(function(){
'use strict';
if(window.top!==window||window.__datoLoaded)return;window.__datoLoaded=true;
var D=window.DatoDetect;
var defaults={secrets:'block',pii:'warn',financial:'warn',source:'warn',contract:'warn',sensitive:'warn'};
var policies=Object.assign({},defaults);
var rank={allow:0,warn:1,redact:2,block:3};
var bypassUntil=0,bypassText='';
var SITE={'chatgpt.com':'chatgpt','chat.openai.com':'chatgpt','claude.ai':'claude','gemini.google.com':'gemini'}[location.hostname]||'chatgpt';
var SEVERITY_RANK={low:1,medium:2,high:3,critical:4};
var current=null; // the flag whose dialog is open: {action,findings,trigger}

// Tell the service worker what happened to a flagged prompt. Counts and labels only:
// never the prompt text, the matched values or the masked excerpts.
function record(outcome,c){
 var categories={},rules={},worst='low';
 c.findings.forEach(function(f){
  categories[f.category]=(categories[f.category]||0)+1;
  rules[f.ruleId]=(rules[f.ruleId]||0)+1;
  if(SEVERITY_RANK[f.severity]>SEVERITY_RANK[worst])worst=f.severity;
 });
 try{chrome.runtime.sendMessage({type:'dato:event',event:{site:SITE,action:c.action,outcome:outcome,trigger:c.trigger,severity:worst,categories:categories,rules:rules}},function(){void chrome.runtime.lastError})}catch(e){}
}
chrome.storage.local.get(defaults,function(x){policies=Object.assign({},defaults,x)});
chrome.storage.onChanged.addListener(function(changes,area){if(area!=='local')return;Object.keys(defaults).forEach(function(k){if(changes[k])policies[k]=changes[k].newValue})});

var HOST_SELECTORS={
 'chatgpt.com':['#prompt-textarea','textarea#mobile-composer-prompt','textarea[data-id="root"]','div[contenteditable="true"][data-virtualkeyboard="true"]','div[contenteditable="true"].ProseMirror','form textarea'],
 'claude.ai':['div[contenteditable="true"].ProseMirror','fieldset div[contenteditable="true"]','div[contenteditable="true"]','textarea'],
 'gemini.google.com':['div[contenteditable="true"].ql-editor','rich-textarea div[contenteditable="true"]','rich-textarea textarea','textarea']
};
var EDITABLE_SEL='textarea,[contenteditable="true"],input[type="text"]';
var SEND_SELECTORS=['button[data-testid="send-button"]','button[data-testid*="send" i]','button[aria-label*="send" i]','form button[type="submit"]'];

function visible(e){var r=e.getBoundingClientRect();return r.width>20&&r.height>10&&r.bottom>0&&r.top<(window.innerHeight||800)}
function editables(){var out=[];var nodes=document.querySelectorAll(EDITABLE_SEL);for(var i=0;i<nodes.length;i++){if(visible(nodes[i]))out.push(nodes[i])}return out}
function editor(){
 var pref=HOST_SELECTORS[location.hostname]||[];
 for(var i=0;i<pref.length;i++){var e=document.querySelector(pref[i]);if(e&&visible(e))return e}
 // Generic fallback: the visible editable closest to the bottom of the viewport - prompt composers sit at the bottom.
 var all=editables(),best=null,bestBottom=-1;
 for(var j=0;j<all.length;j++){var r=all[j].getBoundingClientRect();if(r.bottom>bestBottom){bestBottom=r.bottom;best=all[j]}}
 return best;
}
function isComposer(el){
 if(!el||!el.matches)return false;
 var ed=editor();
 if(ed&&(ed===el||ed.contains(el)))return true;
 return el.matches(EDITABLE_SEL)&&visible(el);
}
function matchesAny(el,sels){for(var i=0;i<sels.length;i++){try{if(el.matches(sels[i]))return true}catch(e){}}return false}
function isSendButton(b){return b&&!b.disabled&&visible(b)&&matchesAny(b,SEND_SELECTORS)}
function sendButtons(){var out=[];var nodes=document.querySelectorAll(SEND_SELECTORS.join(','));for(var i=0;i<nodes.length;i++){if(!nodes[i].disabled&&visible(nodes[i]))out.push(nodes[i])}return out}
function pickSendButton(ed){
 var btns=sendButtons();if(!btns.length)return null;
 var form=ed&&ed.closest?ed.closest('form'):null;
 for(var i=0;i<btns.length;i++){if(form&&form.contains(btns[i]))return btns[i]}
 if(ed){var er=ed.getBoundingClientRect(),best=null,bestDist=Infinity;
  for(var j=0;j<btns.length;j++){var br=btns[j].getBoundingClientRect();var d=Math.abs(br.top-er.top)+Math.abs(br.left-er.right);if(d<bestDist){bestDist=d;best=btns[j]}}
  return best}
 return btns[0];
}
function textOf(e){return e?(e.tagName==='TEXTAREA'||e.tagName==='INPUT'?e.value:(e.innerText||e.textContent||'')):''}
function setText(e,text){
 e.focus();
 if(e.tagName==='TEXTAREA'||e.tagName==='INPUT'){
  var proto=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  var setter=Object.getOwnPropertyDescriptor(proto,'value').set;
  setter.call(e,text);
  e.dispatchEvent(new Event('input',{bubbles:true}));
  e.dispatchEvent(new Event('change',{bubbles:true}));
  return;
 }
 // Contenteditable / ProseMirror / Gemini: select all, then insertText so the editor updates its own state.
 try{
  var sel=window.getSelection();
  var range=document.createRange();
  range.selectNodeContents(e);
  sel.removeAllRanges();
  sel.addRange(range);
  if(document.execCommand('insertText',false,text))return;
  if(document.execCommand('selectAll',false,null)&&document.execCommand('insertText',false,text))return;
 }catch(err){}
 e.textContent=text;
 try{e.dispatchEvent(new InputEvent('input',{bubbles:true,cancelable:true,inputType:'insertText',data:text}))}catch(err2){e.dispatchEvent(new Event('input',{bubbles:true}))}
}
function policyFor(f){
 var key=(D.policyCategory&&D.policyCategory(f))||f.category;
 var p=policies[key]||'warn';
 if(f.tentative&&rank[p]>rank.warn)p='warn';
 return p;
}
function actionFor(findings){var a='allow';findings.forEach(function(f){var p=policyFor(f);if(rank[p]>rank[a])a=p});return a}
function attempt(e,trigger){var ed=editor();if(!ed)return;var text=textOf(ed).trim();if(!text)return;if(Date.now()<bypassUntil&&text===bypassText)return;var findings=D.scan(text).findings;if(!findings.length)return;var action=actionFor(findings);
 if(action==='allow'){record('allowed',{action:'allow',findings:findings,trigger:trigger});return}
 // A redact policy cannot work on a whole-prompt finding (code, contract language): there is no exact value to replace. Block instead of pretending.
 if(action==='redact'&&findings.some(function(f){return !f.length}))action='block';
 e.preventDefault();e.stopImmediatePropagation();show(action,findings,text,ed,trigger)}

// Send-button clicks (icon clicks land inside the button, so walk up).
document.addEventListener('click',function(e){var b=e.target&&e.target.closest?e.target.closest('button'):null;if(b&&isSendButton(b))attempt(e,'click')},true);
// Enter-to-send. window capture runs before the page's own handlers.
window.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&isComposer(e.target))attempt(e,'enter')},true);
// Safety nets: newline insertion and any real form submit from the composer.
window.addEventListener('beforeinput',function(e){if(e.inputType==='insertParagraph'&&isComposer(e.target))attempt(e,'enter')},true);
document.addEventListener('submit',function(e){var ed=editor();if(ed&&e.target&&e.target.contains&&e.target.contains(ed))attempt(e,'submit')},true);

function resume(ed,text){bypassText=text;bypassUntil=Date.now()+1600;var b=pickSendButton(ed);if(b){b.click();return}ed.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true,cancelable:true}))}
function show(action,findings,text,ed,trigger){close();current={action:action,findings:findings,trigger:trigger};var wrap=document.createElement('div');wrap.className='dato-backdrop';wrap.id='dato-modal';var labels={block:['Blocked by policy','Remove the flagged data before sending. If you meant to share it, use Send anyway.'],warn:['Confidential data detected','Review the findings before choosing to send.'],redact:['Redaction required','AI Firewall can replace the detected values before sending.']};var rows=findings.slice(0,6).map(function(f){return '<div class="dato-finding"><b>'+esc(f.label)+'</b><code>'+esc(f.masked)+'</code></div>'}).join('');var more=findings.length>6?'<div class="dato-more">+'+(findings.length-6)+' more finding'+(findings.length-6===1?'':'s')+'</div>':'';var canRedact=findings.some(function(f){return f.length>0});var leftover=findings.some(function(f){return !f.length});var leftoverNote=(canRedact&&leftover)?'<div class="dato-more">Source code or contract language can\'t be replaced automatically. Those parts would go out unchanged.</div>':'';var buttons='<button class="dato-btn" data-dato="cancel">Go back</button>';
 if(action==='warn'||action==='block'||action==='redact')buttons+='<button class="dato-btn dato-btn-danger" data-dato="send">Send anyway</button>';
 if(canRedact)buttons+='<button class="dato-btn dato-btn-primary" data-dato="redact">Remove and send</button>';
 wrap.innerHTML='<div class="dato-dialog dato-'+action+'" role="dialog" aria-modal="true" aria-labelledby="dato-title"><div class="dato-head"><div class="dato-logo" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v6c0 4.5-3 7.7-7 9-4-1.3-7-4.5-7-9V6z"/><path d="M9 12l2 2 4-4"/></svg></div><div><strong id="dato-title">AI Firewall stopped this prompt</strong><span>Local AI data-leak firewall</span></div></div><div class="dato-verdict"><b>'+labels[action][0]+'</b><div>'+labels[action][1]+'</div></div><div class="dato-findings">'+rows+more+leftoverNote+'</div><div class="dato-local">Scanned on this device. Prompt content was not stored or transmitted by AI Firewall.</div><div class="dato-actions">'+buttons+'</div></div>';
 document.body.appendChild(wrap);sentinel('alert',findings.length+' finding'+(findings.length===1?'':'s'));
 wrap.querySelector('[data-dato="cancel"]').addEventListener('click',cancel);
 var send=wrap.querySelector('[data-dato="send"]');if(send)send.addEventListener('click',function(){if(!send.dataset.armed){send.dataset.armed='1';send.textContent='Really send flagged data? Click again';setTimeout(function(){if(send.isConnected){delete send.dataset.armed;send.textContent='Send anyway'}},5000);return}record('override',current);close();resume(ed,text)});
 var redact=wrap.querySelector('[data-dato="redact"]');if(redact)redact.addEventListener('click',function(){var safe=D.redact(text,findings);record('redacted',current);setText(ed,safe);var now=textOf(ed).trim();close();if(now===safe.trim()||now.indexOf('[REDACTED')!==-1){setTimeout(function(){resume(ed,now)},80)}});
 wrap.addEventListener('click',function(x){if(x.target===wrap)cancel()});document.addEventListener('keydown',escapeOnce,true)
}
// Going back, Escape and clicking outside all mean the prompt was stopped and nothing was sent.
function cancel(){if(current)record('cancelled',current);close()}
function escapeOnce(e){if(e.key==='Escape')cancel()}
function close(){current=null;var m=document.getElementById('dato-modal');if(m)m.remove();document.removeEventListener('keydown',escapeOnce,true);sentinel('', 'Protected locally')}
function sentinel(state,label){var s=document.getElementById('dato-sentinel');if(!s){s=document.createElement('div');s.id='dato-sentinel';s.innerHTML='<i></i><span></span>';document.documentElement.appendChild(s)}s.className=state==='alert'?'dato-alert':'';s.querySelector('span').textContent='AI Firewall · '+label}
function esc(v){var d=document.createElement('div');d.textContent=v;return d.innerHTML}
sentinel('','Protected locally');
})();
